create
    definer = root@localhost procedure listProgettiSenzaCapo()
BEGIN
    SELECT Progetto.nome AS nomeP,Progetto.dataCreazione AS dataP FROM Progetto WHERE cfCapoProgetto IS NULL;
end;

grant execute on procedure listProgettiSenzaCapo to amministratoreChatMulticanale;

