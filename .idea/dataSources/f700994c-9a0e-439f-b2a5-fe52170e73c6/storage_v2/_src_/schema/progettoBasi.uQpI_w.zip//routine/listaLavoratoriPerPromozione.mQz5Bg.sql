create
    definer = root@localhost procedure listaLavoratoriPerPromozione(IN nomeP varchar(25))
BEGIN
    SELECT Lavoratore.cf as cfL,Lavoratore.nome as nomeL,Lavoratore.cognome as cognomeL,(SELECT COUNT(*) FROM Lavoratore join Progetto ON Progetto.cfCapoProgetto=Lavoratore.cf  where cf=cfL ) as numeroCapoProgetto FROM Lavoratore join Lavora ON Lavoratore.cf = Lavora.cfLavoratore WHERE Lavora.nomeProgetto=nomeP;
end;

grant execute on procedure listaLavoratoriPerPromozione to amministratoreChatMulticanale;

