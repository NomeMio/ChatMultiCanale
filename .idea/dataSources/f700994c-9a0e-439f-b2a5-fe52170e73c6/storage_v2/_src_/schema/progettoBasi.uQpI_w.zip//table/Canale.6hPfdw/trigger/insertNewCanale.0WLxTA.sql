create definer = root@localhost trigger insertNewCanale
    before insert
    on Canale
    for each row
begin
    if NOT EXISTS(SELECT * from Lavora as p where p.cfLavoratore=new.cfCreatore and new.nomeProgetto=p.nomeProgetto) then
       SIGNAL sqlstate '45001' SET MESSAGE_TEXT ='Non puoi creare canali in un progetto in cui non lavori';
    end if;
    if new.tipo='PUBLICO' then
        if new.cfCreatore not in(SELECT pr.cfCapoProgetto from Progetto as pr where pr.nome=new.nomeProgetto) then
            SIGNAL sqlstate '45001' SET MESSAGE_TEXT ='Solo il capo progetto puo creare canali publici per il progetto';
        end if;
    else
        if new.cfCreatore not in (SELECT p.cfLavoratore from Messaggio as m join Canale AS c ON c.nome=m.nomeCanale and c.nomeProgetto=m.nomeProgetto join progettoBasi.Partecipa AS p ON p.nomeProgetto=m.nomeProgetto and p.nomeCanale=m.nomeCanale where m.id=new.idMessaggioInalizzante) then
            SIGNAL sqlstate '45001' SET MESSAGE_TEXT ='Puoi creare canali privati solo di messaggi di canali publici a cui appartieni';

        end if;
    end if;
end;

