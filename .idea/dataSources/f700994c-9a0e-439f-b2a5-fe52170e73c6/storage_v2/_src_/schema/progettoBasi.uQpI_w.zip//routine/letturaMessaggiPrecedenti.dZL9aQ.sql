create
    definer = root@localhost procedure letturaMessaggiPrecedenti(IN quantita int, IN idPrimoMessaggio int)
begin
    declare currentId int;
    declare contatore int;
    declare successiVoID int;
    declare risposta int;

    set currentId=idPrimoMessaggio;
    set contatore=1;
    if idPrimoMessaggio is null  then
        SIGNAL sqlstate '45001' set MESSAGE_TEXT ='No message Selected';
    end if;
    loopLettura:LOOP
        IF contatore>quantita or currentId IS NULL then
            LEAVE loopLettura;
        end if;
        set contatore=contatore+1;

        select
            Messaggio.precedente,Messaggio.citato
        into successivoId,risposta
        FROM Messaggio
        where id=currentId;

        select
             mes.id as idM, mes.nomeProgetto as nomeP,
             mes.nomeCanale as nomeCa,mes.testo as testoM,
             mes.precedente as idMP,
             mes.timestamp as timeM,aOri.nome as nomeL,
             aOri.cognome as cognomeL, aOri.cf as cfL,aOri.email as emailL,
             mesRisposta.id as idMR,mesRisposta.testo as testoMR,
             mesRisposta.precedente as idMPR,
             mesRisposta.timestamp as timeMR,aCit.nome as nomeLR,
             aCit.cognome as cognomeLR, aCit.cf as cfLR,aCit.email as emailLR
        FROM Messaggio as mes
        join Lavoratore as aOri on mes.autore=aOri.cf
        left join Messaggio as mesRisposta on mes.citato=mesRisposta.id
        left join Lavoratore as aCit on aCit.cf=mesRisposta.autore
        where mes.id=currentId;
        
        set currentId=successiVoID;
    end loop;
end;

grant execute on procedure letturaMessaggiPrecedenti to lavoratoreChatMulticanale;

