create
    definer = root@localhost function controllaPartecipazioneACanale(cfL varchar(16), nomeCa varchar(25), nomeP varchar(25)) returns int
    deterministic
BEGIN
    -- ritorna 1 se il lavoratore lavora per il progetto 0 altrimenti

    declare e int;
    SELECT COUNT(*) into e from Partecipa where cfLavoratore=cfL and nomeProgetto=nomeP and nomeCanale=nomeCa;
    return e;
END;

