create
    definer = root@localhost function controllaLavora(cf varchar(16), nomeP varchar(25)) returns int deterministic
BEGIN
    -- ritorna 1 se il lavoratore lavora per il progetto 0 altrimenti

    declare e int;
    SELECT COUNT(*) into e from Lavora where Lavora.cfLavoratore=cf and Lavora.nomeProgetto=nomeP;
    return e;
END;

