create
    definer = root@localhost procedure inserisciCapoProgetto(IN cfL varchar(16), IN cfA varchar(16), IN nomeP varchar(25))
BEGIN
    -- non ha bisogno di alcun livello di isolamento particolare 
    update Progetto set Progetto.cfCapoProgetto=cfl,Progetto.cfAmministratore=cfA WHERE Progetto.nome=nomeP;
end;

