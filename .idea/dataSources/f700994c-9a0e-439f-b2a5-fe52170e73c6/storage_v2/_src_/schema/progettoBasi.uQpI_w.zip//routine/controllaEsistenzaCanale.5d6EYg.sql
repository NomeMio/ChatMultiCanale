create
    definer = root@localhost function controllaEsistenzaCanale(nomeCa varchar(25), nomeP varchar(25)) returns int
    deterministic
BEGIN
    -- ritorna 1 se il canale esiste altrimenti 0

    declare e int;
    SELECT COUNT(*) into e from Canale where nomeProgetto=nomeP and nome=nomeCa;
    return e;
END;

