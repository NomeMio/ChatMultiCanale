create
    definer = root@localhost procedure inserisciNuovoCanalePublico(IN nomeCa varchar(25), IN nomeP varchar(25), IN cfL varchar(16))
begin


    declare exit handler for sqlexception
        begin
            rollback;
            resignal;
        end;
    set transaction isolation level read committed ;
    start transaction ;

    insert into Canale (nome, nomeProgetto, cfCreatore, dataCreazione, tipo) values (nomeCa,nomeP,cfL,current_date,'PUBLICO');
    INSERT into Partecipa (cfLavoratore, nomeProgetto, nomeCanale) values (cfL,nomeCa,nomeP);

    commit ;
end;

