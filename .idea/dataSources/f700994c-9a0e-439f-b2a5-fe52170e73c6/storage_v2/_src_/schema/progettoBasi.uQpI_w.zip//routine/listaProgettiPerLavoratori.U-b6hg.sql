create
    definer = root@localhost procedure listaProgettiPerLavoratori(IN cfL varchar(16))
BEGIN
    SELECT Progetto.nome AS nomeP,Progetto.dataCreazione AS dataP,Progetto.cfCapoProgetto as cfC FROM Progetto join Lavora on Progetto.nome = Lavora.nomeProgetto and Lavora.cfLavoratore=cfL;
end;

grant execute on procedure listaProgettiPerLavoratori to lavoratoreChatMulticanale;

