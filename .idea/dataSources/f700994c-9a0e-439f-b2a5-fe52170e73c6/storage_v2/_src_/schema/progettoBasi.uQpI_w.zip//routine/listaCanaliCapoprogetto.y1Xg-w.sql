create
    definer = root@localhost procedure listaCanaliCapoprogetto(IN cfL varchar(16), IN nomeP varchar(25))
BEGIN
        SELECT Canale.nome as nomeCa, Canale.dataCreazione as dataCa, Canale.tipo as tipoCa, EXISTS(SELECT * from Partecipa WHERE Partecipa.nomeProgetto=nomeP and Partecipa.nomeCanale=nomeCa and Partecipa.cfLavoratore=cfL) as partecipaC from Canale where  Canale.nomeProgetto=nomeP;
end;

