create definer = root@localhost trigger insertAddLast
    before insert
    on Messaggio
    for each row
begin
    declare varLast int;
    declare result int;
    set result=controllaPartecipazioneACanale(new.autore,new.nomeCanale,new.nomeProgetto);
    if(result=0)then
        SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT ='lavoratore non partecipa a questo canale';
    end if;
    if( new.citato is not null)then
        set result=controllaMessaggioAppartieneAlCanale(new.citato,new.nomeCanale,new.nomeProgetto);
        if(result=0)then
            SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT ='Il messaggio a cui si vuole rispondere non appartiene a questo canale';
        end if;
    end if;

    -- inserimento del messaggio precedente nel canale
    select  idUltimoMessaggio into varLast from Canale where Canale.nome=new.nomeCanale and Canale.nomeProgetto=new.nomeProgetto;
    set new.precedente=varLast;
end;

