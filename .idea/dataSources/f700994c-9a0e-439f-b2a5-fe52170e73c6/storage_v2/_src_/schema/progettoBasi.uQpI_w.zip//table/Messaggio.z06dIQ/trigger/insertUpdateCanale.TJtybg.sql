create definer = root@localhost trigger insertUpdateCanale
    after insert
    on Messaggio
    for each row
begin

   update Canale set Canale.idUltimoMessaggio=new.id where Canale.nome=new.nomeCanale and Canale.nomeProgetto=new.nomeProgetto;

end;

