create
    definer = root@localhost procedure listaCanaliPrivatiLavoratore(IN cfL varchar(16), IN nomeP varchar(25), IN nomeCa varchar(25))
begin
    SELECT
        mes.id as idM, mes.nomeProgetto as nomePO,
        mes.nomeCanale as nomeCaO,mes.testo as testoM,
        canaleP.dataCreazione as dataCa,
        canaleP.nome as nomeCa, canaleP.nomeProgetto as nomeP,
        mes.precedente as idMP,
        mes.timestamp as timeM,autore.nome as nomeL,
        autore.cognome as cognomeL, autore.cf as cfL,autore.email as emailL,
        mesRisposta.id as idMR,mesRisposta.testo as testoMR,
        mesRisposta.precedente as idMPR,
        mesRisposta.timestamp as timeMR,autoreRisposta.nome as nomeLR,
        autoreRisposta.cognome as cognomeLR, autoreRisposta.cf as cfLR,autoreRisposta.email as emailLR,
        altroPartecipante.nome as nomeL2, altroPartecipante.cognome as cognomeL2, altroPartecipante.cf as cfL2,
        altroPartecipante.email as emailL2
    from Canale as canaleP
    join Partecipa as partecipa2 on partecipa2.nomeProgetto=nomeP and partecipa2.nomeCanale=canaleP.nome and partecipa2.cfLavoratore=cfl
    join Messaggio as mes on canaleP.idMessaggioInalizzante=mes.id
    join Lavoratore as autore on mes.autore=autore.cf   -- UNO DEI PARTECIPANTI AL CANALE
    left join Messaggio as mesRisposta on mesRisposta.id=mes.citato
    left join Lavoratore as autoreRisposta on mesRisposta.autore=autoreRisposta.cf
    join Partecipa as partecipazione on partecipazione.nomeProgetto=nomep and partecipazione.nomeCanale=canaleP.nome and partecipazione.cfLavoratore!= autore.cf
    join Lavoratore as altroPartecipante on partecipazione.cfLavoratore=altroPartecipante.cf -- L'altro partecipante
    where canaleP.tipo='PRIVATO'  and nomeCa=mes.nomeCanale;
    end;

grant execute on procedure listaCanaliPrivatiLavoratore to lavoratoreChatMulticanale;

