create
    definer = root@localhost procedure inserisciMessaggio(IN cfL varchar(16), IN nomeCa varchar(25),
                                                          IN nomeP varchar(25), IN testoM longtext, IN idMR int)
begin
    declare tempo TIMESTAMP;

    declare exit handler for sqlexception
        begin
            rollback;
            resignal;
        end;
    set transaction isolation level repeatable read ;
    -- Repeatable read perche vogliamo far si che il trigger che viene attivato dal inserimento del messaggio
    -- Possa modificare tranquilamanete l'ultimo messaggio nel canale senza aggiornamenti fantasmi
    start transaction ;

    set tempo =current_timestamp;
    if idMR is NULL or idMR=0 THEN
        INSERT INTO Messaggio  (autore,timestamp,testo,nomeCanale,nomeProgetto) values (cfL,tempo,testoM,nomeCa,nomeP);
    else
        INSERT INTO Messaggio  (autore,timestamp,testo,nomeCanale,nomeProgetto,citato) values (cfL,tempo,testoM,nomeCa,nomeP,idMR);
    end if;
    commit ;
end;

grant execute on procedure inserisciMessaggio to lavoratoreChatMulticanale;

