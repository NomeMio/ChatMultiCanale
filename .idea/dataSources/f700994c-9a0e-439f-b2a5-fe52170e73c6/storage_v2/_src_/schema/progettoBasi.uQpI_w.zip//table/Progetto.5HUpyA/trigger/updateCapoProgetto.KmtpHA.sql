create definer = root@localhost trigger updateCapoProgetto
    before update
    on Progetto
    for each row
begin
        declare result int;
    if (new.cfCapoProgetto!=old.cfCapoProgetto)then

        SELECT controllaLavora(new.cfCapoProgetto,old.nome) into result;
        if result=1 then
            SELECT COUNT(*) into result FROM Progetto as k where k.cfCapoProgetto IS NOT NULL  AND k.nome=new.nome;
            if result=1 then
                SIGNAL SQLSTATE '45001' set message_text ='Il progetto ha gia un capo';
            end if;
        else
            SIGNAL SQLSTATE '45001' set message_text ='Il lavoratore non lavora per il progetto scelto';
        end if;
    end if;
end;

