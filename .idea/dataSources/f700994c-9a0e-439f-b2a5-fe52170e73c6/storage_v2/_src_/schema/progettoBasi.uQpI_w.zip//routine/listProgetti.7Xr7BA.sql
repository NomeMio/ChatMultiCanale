create
    definer = root@localhost procedure listProgetti()
BEGIN
    SELECT Progetto.nome AS nomeP,Progetto.dataCreazione AS dataP,Lavoratore.cf as cfC, Lavoratore.nome as nomeC,Lavoratore.cognome as cognomeC,Lavoratore.email as emailC FROM Progetto left join Lavoratore ON Progetto.cfCapoProgetto=Lavoratore.cf ORDER BY cfc desc ;
end;

grant execute on procedure listProgetti to amministratoreChatMulticanale;

