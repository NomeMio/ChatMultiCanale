create
    definer = root@localhost procedure letturaUltimiMessaggiCanale(IN quantita int, IN nomeCa varchar(25), IN nomeP varchar(25))
begin
   declare idUltimo int;
   declare exit handler for sqlexception
       begin
           rollback;
           resignal;
       end;
   set transaction isolation level read committed ;
   -- potrei mettere un repeatable read in modo che durante la mia lettura l'ultimo messaggio rimanga lo 
   -- stesso durante tutta la mia lettura, questo pero non giova in nessun modo alle transazioni e al utente 
   -- rallenta solo la scrittura di nuovi messaggi ulteriormente
   start transaction ;
   SELECT Canale.idUltimoMessaggio into idUltimo from Canale where nome=nomeCa and nomeProgetto=nomeP;
   if idUltimo is not null then
       call letturaMessaggiPrecedenti(quantita,idUltimo);
    else
        SIGNAL sqlstate '45001' set MESSAGE_TEXT ='Il canale è vuoto';
   end if;
   commit ;
end;

grant execute on procedure letturaUltimiMessaggiCanale to lavoratoreChatMulticanale;

