create definer = root@localhost trigger controlloPartecipazione
    before insert
    on Partecipa
    for each row
BEGIN
    declare con int;
    declare en varchar(25);
    SELECT count(*) into con from Lavora where Lavora.cfLavoratore= new.cfLavoratore and Lavora.nomeProgetto=new.nomeProgetto;
    if con=0 then
        SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT ='Lavoratore non lavora per quel progetto';
    end if;
    SELECT Canale.tipo into en from Canale where new.nomeCanale=nome and new.nomeProgetto=Canale.nomeProgetto;
    if(en='PRIVATO') then
        SELECT count(*) INTO con from Partecipa where Partecipa.nomeProgetto=new.nomeProgetto and Partecipa.nomeCanale=new.nomeCanale;
        if(con>=2)then
            SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT ='Impossibile aggiungere piu di due persone ad un canale privato';
        end if;
    end if;
end;

