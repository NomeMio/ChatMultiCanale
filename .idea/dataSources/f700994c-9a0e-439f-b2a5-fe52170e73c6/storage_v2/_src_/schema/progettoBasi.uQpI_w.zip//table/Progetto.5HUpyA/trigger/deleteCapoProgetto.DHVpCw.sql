create definer = root@localhost trigger deleteCapoProgetto
    before update
    on Progetto
    for each row
begin
        if new.cfCapoProgetto is null and old.cfCapoProgetto is not null then
            set NEW.cfAmministratore=null;
        end if;
    end;

