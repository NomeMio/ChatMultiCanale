create
    definer = root@localhost procedure login(IN usernameUtenteInput varchar(20), IN passwordUtenteInput varchar(45),
                                             OUT result int, OUT cfResutl varchar(16), OUT emailResutl varchar(45),
                                             OUT nomeResutl varchar(45), OUT cognomeResutl varchar(45))
BEGIN
    -- result=0 login fallito, result=2 amministratore, result=1 lavoratore
    declare cfA varchar(16);
    declare cfL varchar(16);
    set cfResutl ='';
    set result=0;
    select cfAmministratore,cfLavoratore into cfA,cfL from Credenziali where Credenziali.username=usernameUtenteInput AND Credenziali.password=sha2(passwordUtenteInput,224);
    if(cfA IS NOT NULL) then
        set cfResutl=cfA;
        select Amministratore.nome,Amministratore.cognome,Amministratore.email into nomeResutl,cognomeResutl,emailResutl from Amministratore where Amministratore.cf=cfResutl;
        set result=2;
    elseif(cfL IS NOT NULL) THEN
        set cfResutl=cfL;
        select Lavoratore.nome,Lavoratore.cognome,Lavoratore.email into nomeResutl,cognomeResutl,emailResutl from Lavoratore where Lavoratore.cf=cfResutl;
        set result=1;
    end if;

end;

grant execute on procedure login to loginChatmulticanale;

