create
    definer = root@localhost procedure listaCanaliPubliciLavoratore(IN cfL varchar(16), IN nomeP varchar(25))
BEGIN
        SELECT Canale.nome AS nomeCa,Canale.dataCreazione as dataCa,Canale.nomeProgetto as nomeP,Canale.tipo as tipoCa  from Canale join Partecipa on Partecipa.nomeProgetto=nomeP and Partecipa.nomeCanale=Canale.nome and Partecipa.cfLavoratore=cfL where tipo='PUBLICO';
end;

grant execute on procedure listaCanaliPubliciLavoratore to lavoratoreChatMulticanale;

