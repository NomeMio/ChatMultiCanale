create
    definer = root@localhost function controllaMessaggioAppartieneAlCanale(idM varchar(16), nomeCa varchar(25), nomeP varchar(25)) returns int
    deterministic
BEGIN
    -- ritorna 1 se il lavoratore lavora per il progetto 0 altrimenti

    declare e int;
    SELECT COUNT(*) into e from Messaggio where id=idM and nomeProgetto=nomeP and nomeCanale=nomeCa;
    return e;
END;

