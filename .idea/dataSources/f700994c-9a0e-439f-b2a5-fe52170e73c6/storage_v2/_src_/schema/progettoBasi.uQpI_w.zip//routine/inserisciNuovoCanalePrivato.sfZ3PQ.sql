create
    definer = root@localhost procedure inserisciNuovoCanalePrivato(IN idM int, IN cfL varchar(16))
begin
    declare cfAltro varchar(16);
    declare nomeCa varchar(25);
    declare newChannelName varchar(25);
    declare nomeP varchar(25);
    declare exit handler for sqlexception
        begin
            rollback;
            resignal;
        end;
    set transaction isolation level read committed ;
    start transaction ;
    select Messaggio.nomeProgetto, Messaggio.nomeCanale, Messaggio.autore into nomeP,nomeCa,cfAltro from Messaggio where idM=Messaggio.id;
    if(cfL=cfAltro)then
        signal SQLSTATE '45001' SET MESSAGE_TEXT ='Non puoi creare un canale privato con te stesso';
    end if;
    set newChannelName=concat(nomeCa,cfAltro,nomeP,cfL);
    set newChannelName=substr(SHA2(newChannelName,0),1,25);
    INSERT INTO Canale (nome,nomeProgetto,cfCreatore,dataCreazione,tipo,idMessaggioInalizzante) values (newChannelName,nomeP,cfL,CURRENT_DATE,'PRIVATO',idM);
    INSERT into Partecipa(cfLavoratore, nomeProgetto, nomeCanale) values (cfL,nomeP,newChannelName);
    INSERT into Partecipa(cfLavoratore, nomeProgetto, nomeCanale) values (cfAltro,nomeP,newChannelName);
    commit ;
end;

grant execute on procedure inserisciNuovoCanalePrivato to lavoratoreChatMulticanale;

